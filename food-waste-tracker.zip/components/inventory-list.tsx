"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Trash2, AlertTriangle, Clock } from "lucide-react"

interface InventoryItem {
  id: number
  name: string
  category: string
  quantity: number
  unit: string
  expiryDate: string
  daysLeft: number
}

interface InventoryListProps {
  items: InventoryItem[]
}

export function InventoryList({ items }: InventoryListProps) {
  const getExpiryStatus = (daysLeft: number) => {
    if (daysLeft <= 1) return { color: "destructive", icon: AlertTriangle, text: "Expires today" }
    if (daysLeft <= 3) return { color: "secondary", icon: Clock, text: `${daysLeft} days left` }
    return { color: "default", icon: Clock, text: `${daysLeft} days left` }
  }

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      Fruits: "bg-orange-100 text-orange-800",
      Vegetables: "bg-green-100 text-green-800",
      Dairy: "bg-blue-100 text-blue-800",
      Meat: "bg-red-100 text-red-800",
      Grains: "bg-yellow-100 text-yellow-800",
      Pantry: "bg-purple-100 text-purple-800",
      Frozen: "bg-cyan-100 text-cyan-800",
      Other: "bg-gray-100 text-gray-800",
    }
    return colors[category] || colors["Other"]
  }

  if (items.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>No items in your inventory yet.</p>
        <p className="text-sm">Add your first item to get started!</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {items.map((item) => {
        const status = getExpiryStatus(item.daysLeft)
        const StatusIcon = status.icon

        return (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-medium">{item.name}</h3>
                    <Badge className={getCategoryColor(item.category)} variant="secondary">
                      {item.category}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>
                      {item.quantity} {item.unit}
                    </span>
                    <div className="flex items-center gap-1">
                      <StatusIcon className="w-3 h-3" />
                      <span>{status.text}</span>
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
